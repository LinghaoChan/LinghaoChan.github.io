import pandas as pd

df = pd.read_excel('./data2_info.xlsx', '企业信息', index_col=0)
para = pd.read_excel('./problem3/risk_rate.xlsx', header=0, index_col=0)

categorys = ['工业', '文化传媒', '商业', '生活服务业', '个体户']
k = {'工业': 0.8, '文化传媒': 0.7, '商业': 0.6, '生活服务业': 0.65, '个体户': 0.9}

para['风险系数'] = 1 - para['风险系数']
para['addition_q'] = 0
for cate in categorys:
    indexs = set(df[df['行业'] == cate].index) & set(para.index)
    for j in indexs:
        if(para['风险系数'][j] == 0):
            para.loc[j, 'addition_q'] = 0
        else:
            para.loc[j, 'addition_q'] = k[cate] / para['风险系数'][j]
total = sum(para['addition_q'])
para['补偿额度'] = para.apply(lambda x: x['addition_q']/total*2000, axis=1)
para['总额度'] = para['补偿额度'] + para['原始额度']

cate1 = df[df['行业'].isin(['技术行业'])]
cate1_index = cate1.index
cate2 = df[df['行业'].isin(['工业', '文化传媒', '商业', '生活服务业', '个体户'])]
cate2_index = cate2.index
cate3 = df[df['行业'].isin(['农林牧渔', '邮政物流'])]
cate3_index = cate3.index

r_cate2 = para[para.index.isin(cate2_index)]['风险系数']
r_cate1 = para[para.index.isin(cate1_index)]['风险系数']


def deal(index, ri, v):
    if (index in cate1_index):
        g = (ri - min(r_cate1))/(max(r_cate1) - min(r_cate1))
        beita = 0.6
        return v*(1+beita*g)
    elif(index in cate2_index):
        g = (ri - min(r_cate2))/(max(r_cate2) - min(r_cate2))
        alpha = 0.6
        return v*(1-alpha*g)
    else:
        return v

para['新利率'] = para.apply(lambda x: deal(x.name, x['风险系数'], x['原始利率']), axis=1)


level1 = para.loc[['E185', 'E336','E179','E267', 'E329'], :]['风险系数']
level2 = para.loc[['E141', 'E308','E308','E387'],:]['风险系数']
level_total = pd.concat([level1,level2], axis=0)


def deal_1(index, ri, v):
    g = (ri - min(level_total))/(max(level_total) - min(level_total))
    if (index in level1.index):
        return v*(1-g)
    elif(index in level2.index):
        return v*(1-0.3*g)
    else:
        return v
para['旱灾利率'] = para.apply(lambda x: deal_1(x.name, x['风险系数'], x['原始利率']), axis=1)

para.to_excel('./problem3/调整后结果.xlsx')
