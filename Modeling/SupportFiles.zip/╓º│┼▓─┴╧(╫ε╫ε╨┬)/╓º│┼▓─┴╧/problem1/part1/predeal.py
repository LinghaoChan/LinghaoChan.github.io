import pandas as pd
import math


data1_in = pd.read_excel('./data1.xlsx', '进项发票信息')
data1_out = pd.read_excel('./data1.xlsx', '销项发票信息')

# 计算月数目
time_a = data1_in.loc[:, ['企业代号', '开票日期']]
time_b = data1_out.loc[:, ['企业代号', '开票日期']]

time_s = pd.concat([time_a, time_b], axis=0)
time_s = time_s.sort_values(by=['企业代号', '开票日期'])
start = time_s.groupby(['企业代号']).first()['开票日期']
end = time_s.groupby(['企业代号']).last()['开票日期']
months = (end-start).dt.days/31
months = months.apply(lambda x: math.ceil(x))


# 1.自身风险部分
# 计算卖出退款率
valid_ticket = data1_out[data1_out['发票状态'] == '有效发票']

sell_fail = valid_ticket[valid_ticket['价税合计'] < 0].groupby('企业代号')[
    '价税合计'].count()
fail_rate = sell_fail / valid_ticket.groupby('企业代号')['价税合计'].count() * 100
fail_rate = fail_rate.fillna(0)


# 卖出取消订单率
invalid_ticket_out = data1_out[data1_out['发票状态'] == '作废发票']

sell_cancel = invalid_ticket_out.groupby('企业代号')['价税合计'].count()
sell_cancel_rate = sell_cancel / \
    data1_out.groupby('企业代号')['价税合计'].count() * 100
sell_cancel_rate = sell_cancel_rate.fillna(0)

# 月均卖出取消订单量
cancel_num_series_out = invalid_ticket_out.groupby(
    ['企业代号'])['价税合计'].count()/months

# 买入取消订单率
invalid_ticket_in = data1_in[data1_in['发票状态'] == '作废发票']

buy_cancel = invalid_ticket_in.groupby('企业代号')['价税合计'].count()
buy_cancel_rate = buy_cancel / data1_in.groupby('企业代号')['价税合计'].count() * 100
buy_cancel_rate = buy_cancel_rate.fillna(0)

# 月均买入取消订单量
cancel_num_series_in = invalid_ticket_in.groupby(
    ['企业代号'])['价税合计'].count()/months


# 月均买入总交易量
valid_ticket_in = data1_in[data1_in['发票状态'] == '有效发票']
valid_ticket_out = data1_out[data1_out['发票状态'] == '有效发票']

total_in = valid_ticket_in.loc[:, ['企业代号', '金额']].groupby('企业代号').sum()
in_series = valid_ticket_in.loc[:, ['企业代号', '金额']].groupby(['企业代号']).sum()
in_series = in_series.div(months, axis=0)

# 月均卖出总交易量
total_out = valid_ticket_out.loc[:, ['企业代号', '金额']].groupby('企业代号').sum()
out_series = valid_ticket_out.loc[:, ['企业代号', '金额']].groupby(
    ['企业代号']).sum()
out_series = out_series.div(months, axis=0)

# 月均总交易总量
tmp = pd.concat([in_series, out_series], axis=1)
tmp.columns = ['买入', '卖出']
total_in_and_out = tmp['卖出'] + tmp['买入']

money_in = valid_ticket_in.loc[:, ['企业代号', '开票日期', '价税合计']]
money_in['买入'] = money_in['价税合计']

money_out = valid_ticket_out.loc[:, ['企业代号', '开票日期', '金额']]
money_out['卖出'] = money_out['金额']

money_series = pd.concat([money_in, money_out], axis=0,
                         ignore_index=True).fillna(0)
money_series = money_series.sort_values(by=['企业代号', '开票日期'])
money_series['差额'] = money_series['卖出'] - money_series['买入']

# 计算年均净利润
data_2 = money_series.groupby(['企业代号', money_series['开票日期'].dt.year])['差额'].sum()
data_2 = data_2.groupby(['企业代号']).mean()
data_2.to_excel('./problem1/result/average_income_year.xlsx')
# money_series['计算按年'] = data_2['差额'].cumsum()

# 月净利润
per_income = money_series.groupby(
    ['企业代号'])['差额'].sum()/months
per_income_fangcha = money_series.groupby(['企业代号'])['差额'].std()

# 月均进销项有效发票数
a = valid_ticket_in.groupby(
    ['企业代号'])['开票日期'].count()/months
b = valid_ticket_out.groupby(
    ['企业代号'])['开票日期'].count()/months
tmp = pd.concat([a, b], axis=1)
tmp.columns = ['买入', '卖出']
tmp = tmp.fillna(0)
valid_ticket_series = tmp['卖出'] + tmp['买入']

# 2.上游风险部分
# 上游公司数随每月变化
up_num_series = valid_ticket_in.groupby(['企业代号', valid_ticket_in['开票日期'].dt.year,
                                         valid_ticket_in['开票日期'].dt.month])['销方单位代号'].nunique()

up_cancel = valid_ticket_in[valid_ticket_in['价税合计'] < 0].groupby(['企业代号'])[
    '销方单位代号'].count()/months

v = valid_ticket_in.groupby(['企业代号', '销方单位代号'])['价税合计'].sum()
in_std = v.reset_index().groupby('企业代号').std().fillna(0)


# 3.下游风险部分
down_num_series = valid_ticket_out.groupby(['企业代号', valid_ticket_out['开票日期'].dt.year,
                                            valid_ticket_out['开票日期'].dt.month])['企业代号'].nunique()

down_cancel = valid_ticket_out[valid_ticket_out['价税合计'] < 0].groupby(['企业代号'])[
    '企业代号'].count()
down_cancel = down_cancel.div(months, axis=0)

o = valid_ticket_out.groupby(['企业代号', '购方单位代号'])['价税合计'].sum()
out_std = o.reset_index().groupby('企业代号').std().fillna(0)


# 4.企业信息处理
data1_info = pd.read_excel('./data1_info.xlsx', '企业信息')

def cal_redit(a, b):
    ll1 = ['D', 'C', 'B', 'A']
    ll2 = ['是', '否']
    return ll1.index(a) * ll2.index(b)


data1_info['信誉度'] = data1_info.apply(
    lambda x: cal_redit(x['信誉评级'], x['是否违约']), axis=1)
credit = data1_info.loc[:, ['企业代号', '信誉度']].set_index('企业代号')

# 5.行业风险计算
category = data1_info['行业'].drop_duplicates().to_numpy()
risk = {}
for i in category:
    ok = data1_info[(data1_info['行业'] == i) & (
        data1_info['是否违约'] == '否')].count()['企业名称']
    total = data1_info[data1_info['行业'] == i].count()['企业名称']
    risk[i] = 1 - ok/total

data1_info['行业违约率'] = data1_info.apply(lambda x: risk[x['行业']], axis=1)
risk_series = data1_info.loc[:, ['企业代号', '行业违约率']].set_index('企业代号')


# 结果生成部分
res = pd.concat([down_cancel, per_income, per_income_fangcha, total_in_and_out, up_cancel, in_std, cancel_num_series_out,
                 out_std,  credit, risk_series], axis=1)
print(res)
res = (res-res.min())/(res.max()-res.min())
res = res.fillna(0)
res.columns = ['卖出取消次数', '净利润', '净利润方差', '交易总额',
               '买入取消次数',  '上游依赖度', '卖出作废次数', '下游依赖度', '自身信誉度', '行业违约率']
res['净利润'] = 1-res['净利润']
res['交易总额'] = 1-res['交易总额']
res['自身信誉度'] = 1-res['自身信誉度']
print(res)
res.to_excel('./problem1/result/problem1_part1.xlsx')
