import pandas as pd
import numpy as np
from pandas.core.frame import fmt

df = pd.read_excel('./problem1/result/problem1_part1.xlsx', index_col=0)
data = df.iloc[:, [0, 1, 2, 3, 4, 5, 7, 8, 9]].to_numpy()
xishu = pd.read_excel('./problem1/result/lambda.xlsx', index_col=0, header=0)
xishu = xishu.to_numpy()
data0 = np.dot(data, xishu)

# 把结果同向化
data0[:,3] = -data0[:,3]

def entropy(data0):
    # 返回每个样本的指数
    # 样本数，指标个数
    n, m = np.shape(data0)
    # 一行一个样本，一列一个指标
    # 下面是归一化
    maxium = np.max(data0, axis=0)
    minium = np.min(data0, axis=0)
    data = (data0-minium)*1.0/(maxium-minium)
    # 计算第j项指标，第i个样本占该指标的比重
    sumzb = np.sum(data, axis=0)
    data = data/sumzb
    # 对ln0处理
    a = data*1.0
    a[np.where(data == 0)] = 0.0001
    # 计算每个指标的熵
    e = (-1.0/np.log(n))*np.sum(data*np.log(a), axis=0)
    # 计算权重
    w = (1-e)/np.sum(1-e)
    print(w)
    recodes = np.sum(data0*w, axis=1)
    return recodes

res = entropy(data0)
res = (res-np.min(res))/(np.max(res) - np.min(res))

info = pd.read_excel('./data1_info.xlsx', '企业信息')
info = info.sort_values(['企业代号'])


def deal(rank, ifOff):
    ll1 = ['D', 'A', 'B', 'C']
    ll2 = ['是', '否']
    if(rank == 'D' or ifOff == '是'):
        return -1
    else:
        return ll1.index(rank) * ll2.index(ifOff)


info['类型'] = info.apply(lambda x: deal(x['信誉评级'], x['是否违约']), axis=1)
# info.to_excel('./indexnum.xlsx')
res1 = info['类型'].to_numpy().reshape(-1, 1)


res = np.hstack([res.reshape(-1, 1), res1, data0])
res = pd.DataFrame(res).set_index(info['企业代号'])
res = res[res[1] > 0]
res.to_csv('./problem1/result/risk_rate.csv')
