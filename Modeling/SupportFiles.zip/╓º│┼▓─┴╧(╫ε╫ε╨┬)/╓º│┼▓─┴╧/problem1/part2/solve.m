clear;
close all;
clc;

para = csvread('../result/risk_rate.csv',1,1);
[m,~] = size(para);

low = ones(1,m*2);
low(1, 1:m) = low(1, 1:m)*0.04;
low(1, m+1:end) = low(1, m+1:end)*1;

up = ones(1,m*2);
up(1, 1:m) = up(1, 1:m)*0.15;
up(1, m+1:end) = up(1, m+1:end) * 10;

Aeq = ones(1,m*2);
Aeq(1, 1:m) = Aeq(1, 1:m)*0;

% options = optimoptions('fmincon','MaxFunctionEvaluations',4e3)
[x,fval] = fmincon(@income_old, ones(m*2,1)*20,Aeq,100,[],[], low, up,[])
x(m+1:end) = round(x(m+1:end))*10;

csvwrite('../problem1_result.csv',x)
