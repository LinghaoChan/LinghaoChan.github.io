# 计算平均年利润
import pandas as pd
import numpy as np
import math

data = pd.read_excel('./problem1/result/average_income_year.xlsx', index_col=0)
info = pd.read_excel('./data1_info.xlsx', '企业信息', index_col=0)

df = pd.concat([info['信誉评级'], info['是否违约'], data], axis=1).sort_index()
df = df[(df['差额'] > 0) & (df['信誉评级'] != 'D')]


res = np.empty([0, 10])
vator = {'A': 0.8, 'B': 1, 'C': 1.2}
changshu = {'A': 2, 'B': 1.8, 'C': 1.6}
p_data={'A': 1, 'B': 0.9, 'C': 0.8}
for index, row in df.iterrows():
    print(index)
    tmp = np.zeros([1, 10])

    category = row['信誉评级']

    index_start = math.floor(row['差额'] * vator[category] // 10e4)
    tmp[0, :index_start] = p_data[category]

    if(index_start > 9):
        res = np.append(res, tmp, axis=0)
        continue
    for j in range(index_start, 10):
        tmp[0, j] = changshu[category] / \
            (1+math.exp((j+1)*10 - vator[category] * row['差额'] / 1e4))
    res = np.append(res, tmp, axis=0)
    print(res)

np.savetxt('./problem1/result/part2_array.csv', res, fmt='%.6f', delimiter=',')
