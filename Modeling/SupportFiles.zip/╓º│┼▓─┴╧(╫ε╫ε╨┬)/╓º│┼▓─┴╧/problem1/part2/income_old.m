function f = income_old(x)
    [m,~] = size(x);
    
    rate = x(1:m/2, :);
    quota = x(m/2+1:end, :); %每万
    
    para = csvread('../result/risk_rate.csv',1,1);

    beita = zeros(m/2,1);
    category = para(:,2);
    for i=1:m/2
        if(category(i) == 1)
            beita(i) = 2.856*(rate(i)-0.04)^0.5;
        elseif(category(i) == 2)
            beita(i) = 2.728*(rate(i)-0.04)^0.5;
        elseif(category(i) == 3)
            beita(i) = 2.707*(rate(i)-0.04)^0.5;
        end
    end

    alpha = para(:,1);
    
   
    tmp = (alpha .* rate .* quota - (-alpha) .* quota*1000) .* (1-beita*1.8);
    f = -sum(tmp);

end

