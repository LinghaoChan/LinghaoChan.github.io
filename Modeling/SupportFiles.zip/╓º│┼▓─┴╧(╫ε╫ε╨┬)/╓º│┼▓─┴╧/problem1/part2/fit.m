clear;
close all;
clc;

data = xlsread('../../data3.xlsx');
x = data(:,1);

figure(1)
hold on;

for i=2:4
    y=data(:,i);
    plot(x,y,'o');
    
    [parameter,resnorm]=lsqcurvefit(@fun,[0.1,3],x,y)
    
    xi=0.03:0.001:0.15;
    yi = fun(parameter,xi);
    plot(xi,yi);
end

xlabel('利率')
ylabel('客户流失率')
