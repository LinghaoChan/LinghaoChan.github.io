function f = fun(a,x)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
    f = a(2).*(x-a(1)).^(1/2);
end

