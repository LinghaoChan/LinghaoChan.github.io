clear;
close all;
clc;

para = csvread('../result/risk_rate_add.csv',1,1);
[m,~] = size(para);

low = ones(1,m*2+1);
low(1, 1:m) = low(1, 1:m)*0.04;
low(1, m+1:end-1) = low(1, m+1:end-1)*1;
low(1, end) = 0;

up = ones(1,m*2+1);
up(1, 1:m) = up(1, 1:m)*0.15;
up(1, m+1:end-1) = up(1, m+1:end-1) * 10;

Aeq = ones(1,m*2+1);
Aeq(1, 1:m) = Aeq(1, 1:m)*0;
Aeq(1, m*2+1) = 0;

options = optimoptions('fmincon','MaxFunctionEvaluations',8e4,'StepTolerance', 1e-3);
[x,fval] = fmincon(@income_old, rand(m*2+1,1)*10,[],[],Aeq,1000, low, up,[])
x(m+1:end-1) = round(x(m+1:end-1))*10;
sum(x(m+1:end-1))

csvwrite('../result/problem2_result.csv',x)


