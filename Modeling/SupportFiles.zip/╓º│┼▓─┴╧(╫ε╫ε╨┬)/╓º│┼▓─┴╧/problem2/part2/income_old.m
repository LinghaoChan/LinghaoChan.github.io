function f = income_old(x)
    [m,~] = size(x);
    m=m-1;

    rate = x(1:m/2, :);
    quota = round(x(m/2+1:end-1, :));  % 每10万
    
    para = csvread('../result/risk_rate_add.csv',1,1);

    beita = zeros(m/2,1);
    category = para(:,2);
    for i=1:m/2
        if(category(i) == 1)
            beita(i) = 2.856*(rate(i)-0.04)^0.5;
        elseif(category(i) == 2)
            beita(i) = 2.728*(rate(i)-0.04)^0.5;
        elseif(category(i) == 3)
            beita(i) = 2.707*(rate(i)-0.04)^0.5;
        end
    end
    alpha = para(1:end-1,1);
    
    res=0;
    for i=1:m/2-1
        if para(i,6)==-1
            tmp = (alpha(i) * rate(i) *beita(i) - (1-alpha(i)) * quota(i)*1000 ) * (1-beita(i)*1.8);
        else
            t0 = para(i,6)/12;
            t1 = 1-para(i,6)/12;
            tmp = t0*(alpha(i) .* rate(i) .*beita(i) .* x(m+1) - (1-alpha(i)) .* quota(i) * 1000 ) * (1-beita(i)*1.8) + t1.*(alpha(i) .* rate(i) .*beita(i) - (1-alpha(i)) * quota(i)*1000) * (1-beita(i)*1.8);
        end
        res = res+tmp;
    end
    
%     for i=1:m/2-1
%         tmp = (alpha(i) .* rate(i) .* quota(i) - (1-alpha(i)) .* quota(i) *1000) .* (1-beita(i)*1.8);
%         res = res+tmp;
%     end
    
    f = -res;

end

