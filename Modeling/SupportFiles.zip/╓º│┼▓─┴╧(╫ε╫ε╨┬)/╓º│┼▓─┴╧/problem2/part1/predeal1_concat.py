import pandas as pd
import math


# 4.企业信息处理
info = pd.read_csv('./problem2/result/predit_label.csv', header=0, index_col=0)
info.columns=['粗筛','信誉评级','是否违约']

def cal_redit(a, b):
    ll1 = ['D', 'A', 'B', 'C']
    ll2 = ['是', '否']
    if(a==4 or b==1):
        return -1
    return a*(1-b)


info['信誉度'] = info.apply(lambda x: cal_redit(x['信誉评级'], x['是否违约']), axis=1)
credit = info['信誉度']

part = pd.read_excel('./problem2/result/problem2_part1_getres.xlsx', index_col=0, header=0)

res = pd.concat([part, credit], axis=1)

# 合成最后结果
res.to_excel('./problem2/result/problem2_part1_getres_res.xlsx')