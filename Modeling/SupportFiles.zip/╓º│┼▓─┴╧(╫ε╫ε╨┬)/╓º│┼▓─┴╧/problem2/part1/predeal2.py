# 提取时间序列信息
import numpy as np
import pandas as pd
import math

data1_in = pd.read_excel('./data2.xlsx', '进项发票信息')
data1_out = pd.read_excel('./data2.xlsx', '销项发票信息')

# 月均买入总交易量
valid_ticket_in = data1_in[data1_in['发票状态'] == '有效发票']
valid_ticket_out = data1_out[data1_out['发票状态'] == '有效发票']

money_in = valid_ticket_in.loc[:, ['企业代号', '开票日期', '价税合计']]
money_in['买入'] = money_in['价税合计']

money_out = valid_ticket_out.loc[:, ['企业代号', '开票日期', '金额']]
money_out['卖出'] = money_out['金额']

money_series = pd.concat([money_in, money_out], axis=0,
                         ignore_index=True).fillna(0)
money_series = money_series.sort_values(by=['企业代号', '开票日期'])
money_series['差额'] = money_series['卖出'] - money_series['买入']

money_series = money_series[money_series['开票日期'].dt.year == 2019]
per_income_series = money_series.groupby(['企业代号', money_series['开票日期'].dt.month])['差额'].sum()
# per_income_series.to_excel('./tmp.xlsx')


index=[]
for i in set(money_series['企业代号']):
    for month in range(1,13):
        index.append((i,month))
series = pd.DataFrame(index= pd.Index(index,names=["企业代号","开票日期"]))

res = pd.concat([per_income_series, series], axis=1).fillna(0).reset_index()


res_list={}
for i in set(money_series['企业代号']):
    data = res[res['企业代号']==i].to_numpy()[:,2]
    for k in range(1,7):
        x = data[:(12-k)]
        y = data[k:]
        x_ba = np.mean(x)
        y_ba = np.mean(y)
        r = np.sum((x - x_ba)*(y - y_ba)) / np.sqrt(np.sum(np.square(x-x_ba))) / np.sqrt(np.sum(np.square(y-y_ba)))
        # print(r)
        
        if(r>0.6):
            res_list[i] = k
            break
    else:
        res_list[i] = -2

df = pd.read_csv('./problem2/result/risk_rate.csv',header=0, index_col=0)

def deal(index):
    return res_list[index]/2

df['周期']=df.apply(lambda x: deal(x.name), axis=1)
df.to_csv('./problem2/result/risk_rate_add.csv')