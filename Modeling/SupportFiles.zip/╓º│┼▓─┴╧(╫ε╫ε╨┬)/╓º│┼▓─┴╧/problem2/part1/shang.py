import pandas as pd
import numpy as np

df = pd.read_excel('./problem2/result/problem2_part1_getres_res.xlsx', index_col=0)
data = df.iloc[:, [0, 1, 2, 3, 4, 6, 7]].to_numpy()
xishu = pd.read_excel('./problem2/result/lambda.xlsx', index_col=0, header=0)
xishu = xishu.to_numpy()
data0 = np.dot(data, xishu)


def entropy(data0):
    # 返回每个样本的指数
    # 样本数，指标个数
    n, m = np.shape(data0)
    # 一行一个样本，一列一个指标
    # 下面是归一化
    maxium = np.max(data0, axis=0)
    minium = np.min(data0, axis=0)
    data = (data0-minium)*1.0/(maxium-minium)
    # 计算第j项指标，第i个样本占该指标的比重
    sumzb = np.sum(data, axis=0)
    data = data/sumzb
    # 对ln0处理
    a = data*1.0
    a[np.where(data == 0)] = 0.0001
    # 计算每个指标的熵
    e = (-1.0/np.log(n))*np.sum(data*np.log(a), axis=0)
    # 计算权重
    w = (1-e)/np.sum(1-e)
    print(w)
    recodes = np.sum(data0*w, axis=1)
    return recodes

res = entropy(data0)
res = (res-np.min(res))/(np.max(res) - np.min(res))

# 4.企业信息处理
info = pd.read_csv('./problem2/result/predit_label.csv', header=0, index_col=0)
info.columns=['粗筛','信誉评级','是否违约']

def cal_redit(a, b):
    ll1 = ['D', 'A', 'B', 'C']
    ll2 = ['是', '否']
    if(a==4 or b==1):
        return -1
    return a*(1-b)


info['信誉度'] = info.apply(lambda x: cal_redit(x['信誉评级'], x['是否违约']), axis=1)
credit = info['信誉度'].to_numpy().reshape(-1, 1)

res = np.hstack([res.reshape(-1, 1),credit,data0])

res=pd.DataFrame(res).set_index(df.index)
res = res[res[1] > 0]
res.to_csv('./problem2/result/risk_rate.csv')


# np.savetxt('./problem2/result/risk_rate.csv', res, delimiter=',', fmt='%.3f')
