# 完成指标恢复工作

import numpy as np
import pandas as pd
from pandas.core.frame import fmt
import sklearn.tree as st
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn import tree

# 这个包含标签是第一问数据用于训练
df = pd.read_excel('./problem2/result/problem2_part1_train.xlsx', index_col=0)
df1 = pd.read_excel('./problem2/result/problem2_part1_getres.xlsx', index_col=0)

data = df.iloc[:, [0,1,2,3,4,5,7,8,9,10]].to_numpy()
y = data[:, 7].astype(int)
y_xinyu=data[:,8].astype(int)
y_if = data[:,9].astype(int)
train_x, test_x, train_y, test_y = train_test_split(data[:,:7], y_if.T, test_size=0.3, random_state=2)

model = st.DecisionTreeClassifier(max_depth=4, criterion='entropy', min_samples_split=8, random_state=2)
# model = MLPClassifier(max_iter = 3000, verbose = True, hidden_layer_sizes=(100,400,400,400), activation='relu')
model.fit(train_x, train_y)
# pred_test_y = model.predict(test_x)
# print(model.score(test_x, test_y))
# print(classification_report(pred_test_y,test_y))

# 获得待预测数据
data1 = df1.iloc[:, [0,1,2,3,4,5,7]].to_numpy()
pred_y = model.predict(data1)

model.fit(data[:,:7], y_xinyu)
res_xinyu = model.predict(data1)

model = st.DecisionTreeClassifier(max_depth=3, criterion='entropy', min_samples_split=8, random_state=2)
model.fit(data[:,:7], y_if)
print(model.score(data[:,:7], y_if))
res_if = model.predict(data1)

# with open("./jueceshu.dot", 'w') as f:
#     f = tree.export_graphviz(model, out_file = f, class_names=['否','是'], rounded=True, filled=True, special_characters=True, feature_names=['卖出取消次数', '净利润', '净利润方差', '交易总额', '买入取消次数', '上游依赖度', '下游依赖度'])

res = np.concatenate([pred_y.reshape(-1,1),res_xinyu.reshape(-1,1), res_if.reshape(-1,1)],axis=1)
res = pd.DataFrame(res).set_index(df1.index)
res.to_csv('./problem2/result/predit_label.csv')
